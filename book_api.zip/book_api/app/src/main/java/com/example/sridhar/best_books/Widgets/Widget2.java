package com.example.sridhar.best_books.Widgets;

import android.content.Intent;
import android.widget.RemoteViewsService;

public class Widget2 extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new MyWidgetRemoteViewsFactory(this.getApplicationContext(),intent);
    }
}
