package com.example.sridhar.best_books;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Loader;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.sridhar.best_books.Data_Books.Books_Volume;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
     BlankFragment blankfragment;
    AdapterMain adapter;
    android.support.v4.app.FragmentManager fragmentManager;
    String Url="https://www.googleapis.com/books/v1/volumes?q=java";
    List<Books_Volume> books_volumes;
    android.support.v4.app.FragmentTransaction fragmentTransaction;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=(RecyclerView)findViewById(R.id.recy1);
        blankfragment=new BlankFragment();

        fragmentManager=getSupportFragmentManager();
        fragmentTransaction=fragmentManager.beginTransaction().replace(R.id.blankfrag,blankfragment);
        fragmentTransaction.commit();

        android.support.v4.app.LoaderManager loaderManager=getSupportLoaderManager();
        android.support.v4.content.Loader<Object> loader=loaderManager.getLoader(1);
        // lm.initLoader(1,null,this);
        loaderManager.initLoader(1,null, (android.support.v4.app.LoaderManager.LoaderCallbacks<Object>) MainActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

    }

    @Override
    public Loader<String> onCreateLoader(int i, Bundle bundle) {
        return new AsyncTaskLoader<String>(this) {
            @Override
            public String loadInBackground() {
                try {
                    URL urll=new URL(Url);
                    HttpURLConnection connection= (HttpURLConnection) urll.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();
                    InputStream is=connection.getInputStream();
                    StringBuilder builder=new StringBuilder();
                    BufferedReader reader=new BufferedReader(new InputStreamReader(is));
                    String line;
                    while ((line=reader.readLine())!=null){
                        builder.append(line);
                    }
                    return  builder.toString();


                } catch (MalformedURLException e) {

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }



    @Override
    public void onLoadFinished(Loader<String> loader, String s) {
        try {
            JSONObject jsonObject=new JSONObject((Map) books_volumes);
            JSONArray items=jsonObject.getJSONArray("items");

            for (int i=0;i<items.length();i++) {
                Books_Volume currentdata= new Books_Volume();

                JSONObject position = items.getJSONObject(i);
                JSONObject info = position.getJSONObject("volumeInfo");
                String title = info.getString("title");
                JSONArray authors_array = info.getJSONArray("authors");
                String author_name = authors_array.getString(0);
                JSONObject image = info.getJSONObject("imageLinks");
                String book_image = image.getString("thumbnail");
                Toast.makeText(MainActivity.this, "" + title + "\n" + author_name + "\n" + book_image, Toast.LENGTH_SHORT).show();
                //name.setText(title);
                //author.setText(author_name);
                Picasso.with(currentdata).load(book_image).into(image);
                currentdata.setAuthor(author_name);
               currentdata.setImage(book_image);
                currentdata.setTitle(title);
                books_volumes.add(currentdata);

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        // blankfragment.rv.setAdapter(new BookApi_adapter(this,dataList1));
        recyclerView.setAdapter(new AdapterMain(MainActivity.this,books_volumes));



    }

    @Override
    public void onLoaderReset(Loader<String> loader) {

    }
}
