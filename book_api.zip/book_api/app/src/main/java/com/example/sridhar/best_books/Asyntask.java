package com.example.sridhar.best_books;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.example.sridhar.best_books.Data_Books.Books_Volume;

import java.util.ArrayList;

public class Asyntask extends AsyncTaskLoader<ArrayList<Books_Volume>> {

    private Context _context;
    private Exception _exception;

    public Asyntask(Context context) {
        super(context);
        this._context = context;
    }

    public ArrayList<Books_Volume> loadInBackground() {

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this._context);

        try {
            ArrayList<Books_Volume> books_volumes = Json_data.books_volumes(Networking.sendHttpRequest("https://www.googleapis.com/books/v1/volumes?q=java", this._context));

            return books_volumes;
        } catch (Exception e) {
            this._exception = e;
            return null;
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return null;
    }

    public Exception getException() {
        return this._exception;
    }
}
