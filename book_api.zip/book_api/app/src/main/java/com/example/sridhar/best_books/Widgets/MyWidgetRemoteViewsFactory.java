package com.example.sridhar.best_books.Widgets;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.sridhar.newtwo.R;

import java.util.BitSet;

import static com.example.sridhar.newtwo.Widgets.Widgets1.list1;

class MyWidgetRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {

    private Context context;
    private Cursor cursor;
    public MyWidgetRemoteViewsFactory(Context applicationContext, Intent intent) {
        context=applicationContext;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {


    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return list1 == null ? 0 : list1.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.home_widget2);
        rv.setTextViewText(R.id.widgetItemTaskNameLabel, list1.get(position).getIngredient());
      //  Intent fillInIntent = new Intent();
        /*fillInIntent.putExtra(Widgets1.EXTRA_LABLE, cursor.getString(1));
        rv.setOnClickFillInIntent(R.id.widgetItemContainer, fillInIntent);*/
        return rv;

    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int position) {
        return  position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}
