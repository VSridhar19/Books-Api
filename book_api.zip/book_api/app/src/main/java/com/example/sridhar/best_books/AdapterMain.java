package com.example.sridhar.best_books;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sridhar.best_books.Data_Books.Books_Volume;

import java.util.List;

class AdapterMain extends RecyclerView.Adapter <AdapterMain.Myholder> {
    Context context;
    List<Books_Volume> list;
    public AdapterMain(MainActivity mainActivity, List<Books_Volume> books_volumes) {
        context=mainActivity;
        list=books_volumes;
    }


    @NonNull
    @Override
    public AdapterMain.Myholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Myholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_blank,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMain.Myholder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class Myholder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        public Myholder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.image1);
            textView=(TextView)itemView.findViewById(R.id.t1);


        }
    }
}
