package com.example.sridhar.best_books.Data_Books;

import java.util.List;

public class Books_Volume {

    private String title;

    private List<String> authors = null;

    private String publisher;

    private String publishedDate;

    private String description;

    private List<Books_industrial> industryIdentifiers = null;

    private Books_reading readingModes;

    private Integer pageCount;

    private String printType;

    private List<String> categories = null;

    private Double averageRating;

    private Integer ratingsCount;

    private String maturityRating;

    private Boolean allowAnonLogging;

    private String contentVersion;

    private Books_image imageLinks;

    private String language;

    private String previewLink;

    private String infoLink;

    private String canonicalVolumeLink;

    private String subtitle;

    private Books_summery panelizationSummary;
    private String author;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public void setAuthors(List<String> authors) {
        this.authors = authors;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(String publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Books_industrial> getIndustryIdentifiers() {
        return industryIdentifiers;
    }

    public void setIndustryIdentifiers(List<Books_industrial> industryIdentifiers) {
        this.industryIdentifiers = industryIdentifiers;
    }

    public Books_reading getReadingModes() {
        return readingModes;
    }

    public void setReadingModes(Books_reading readingModes) {
        this.readingModes = readingModes;
    }

    public Integer getPageCount() {
        return pageCount;
    }

    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    public String getPrintType() {
        return printType;
    }

    public void setPrintType(String printType) {
        this.printType = printType;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        this.categories = categories;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public Integer getRatingsCount() {
        return ratingsCount;
    }

    public void setRatingsCount(Integer ratingsCount) {
        this.ratingsCount = ratingsCount;
    }

    public String getMaturityRating() {
        return maturityRating;
    }

    public void setMaturityRating(String maturityRating) {
        this.maturityRating = maturityRating;
    }

    public Boolean getAllowAnonLogging() {
        return allowAnonLogging;
    }

    public void setAllowAnonLogging(Boolean allowAnonLogging) {
        this.allowAnonLogging = allowAnonLogging;
    }

    public String getContentVersion() {
        return contentVersion;
    }

    public void setContentVersion(String contentVersion) {
        this.contentVersion = contentVersion;
    }

    public Books_image getImageLinks() {
        return imageLinks;
    }

    public void setImageLinks(Books_image imageLinks) {
        this.imageLinks = imageLinks;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getPreviewLink() {
        return previewLink;
    }

    public void setPreviewLink(String previewLink) {
        this.previewLink = previewLink;
    }

    public String getInfoLink() {
        return infoLink;
    }

    public void setInfoLink(String infoLink) {
        this.infoLink = infoLink;
    }

    public String getCanonicalVolumeLink() {
        return canonicalVolumeLink;
    }

    public void setCanonicalVolumeLink(String canonicalVolumeLink) {
        this.canonicalVolumeLink = canonicalVolumeLink;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public Books_summery getPanelizationSummary() {
        return panelizationSummary;
    }

    public void setPanelizationSummary(Books_summery panelizationSummary) {
        this.panelizationSummary = panelizationSummary;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

  //  public void setImage(String image) {
    //    this.image = image;
    }


